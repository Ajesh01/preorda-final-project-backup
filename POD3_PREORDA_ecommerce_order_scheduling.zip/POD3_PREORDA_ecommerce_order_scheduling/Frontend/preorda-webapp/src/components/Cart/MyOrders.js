import React, { useState, useEffect } from 'react';
import './Cartpage.css';
import Navbar from '../Navbar/Navbar';

let user = localStorage.getItem("user_id");

function MyOrders() {

    const [myorders, setmyorders] = useState([]);
    const [myorderdetails, setmyorderdetails] = useState([]);
    let grand_total = 0;
    const [orderIdDisplay, setorderIdDisplay] = useState('');

    useEffect(() => {
        setTimeout(() => {
            // do something 1 sec after clicked has changed
            console.log("USER", user);
        fetch("http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/order/myorders/" +
            user, {
            method: "GET",
            headers: { "Content-Type": "application/json" }

        }).then(async response => {
            const data = await response.json();
            //console.log("data", data);
            if (mounted)
                setmyorders(data);
            console.log(myorders);
        })

        return () => mounted = false;
         }, 1000);
     
        let mounted = true;
        
    }, []);
    function cancelOrder(id) {
        //Remove order from orders table
        //Remove orderdetails for that orderid
        //Remove that order from schedule
        console.log(id);
        fetch("http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/order/myorders/" +
            id, {
            method: "DELETE",
            headers: { "Content-Type": "application/json" },

        }).then(() => {
            alert("Your order cancellation is successfull");
            fetch("http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/order/myorders/" +
                user, {
                method: "GET",
                headers: { "Content-Type": "application/json" }
                // body: JSON.stringify(sellermyproducts)

            }).then(async response => {
                const data = await response.json();
                console.log(data);
                //if(mounted)
                setmyorders(data)

            });
        })

    };

    const viewMyOrderDetails = (order_Id, index) => {
        setorderIdDisplay(myorders[index].order_Id);
        console.log("orderIdDisplay", orderIdDisplay);
        fetch("http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/orderdetails/myorders/" + order_Id, {
            method: "GET",
            headers: { "Content-Type": "application/json" }

        }).then(async response => {
            const data = await response.json();
            setmyorderdetails(data);
            // console.log(myorderdetails);
        });

    };
    let ORDER_DETAILS_HTML = '';
    let ORDER_HTML = '';
    if (myorderdetails.length > 0) {
        ORDER_DETAILS_HTML =
            <div style={{ minHeight: '85vh' }}>
                <div class="container-fluid d-flex justify-content-center align-items-center" style={{ minHeight: '35vh' }} >
                    <div class="card p-3 text-center py-4 login-card">
                        <h4 className='text-center line'>Your Order Details</h4>
                        <strong>Order Id - #Preorda-{orderIdDisplay}</strong>
                        {myorderdetails.map((myorderdetail, index) => {
                            grand_total += myorderdetail.quantity * myorderdetail.subtotal;
                            return (
                                <ul className="list-group mb-3">
                                    <li className="list-group-item d-flex justify-content-between lh-sm" key={index}>
                                        <div>
                                            <h6 className="my-0">{myorderdetail.product_name}</h6>
                                            <small className="text-muted">Quantity = {myorderdetail.quantity} </small>
                                        </div>
                                        <span className="my-1">Rs.{myorderdetail.quantity * myorderdetail.subtotal} /-</span>
                                    </li>
                                </ul>)
                        })}
                        <div className="list-group-item d-flex justify-content-between">
                            <strong>Total Purchase</strong>
                            <strong>Rs.{grand_total + 220} /-</strong>
                        </div>
                        <hr></hr>
                        <span className='line'>THANK YOU for your purchase</span>

                        <span><small className="text-muted">For any queries related to your order, please write us to  </small>
                            <a href="#" className='line'>ecommercesitepreorda@gmail.com</a></span>
                    </div>
                </div>
            </div >

    }
    if (myorders.length > 0) {

        ORDER_HTML =
            <div className="container px-4 px-lg-5 my-5">
                <div className="row">
                    <div className="col-lg-12 p-5 bg-white rounded shadow-sm mb-5">


                        <div className="table-responsive">
                            <table className="table">
                                <thead>
                                    <tr>
                                        <th scope="col" className="border-0 bg-light title-col">
                                            <div className="p-2 px-3 text-uppercase">Order Id</div>
                                        </th>
                                        <th scope="col" className="border-0 bg-light title-col">
                                            <div className="p-2 px-3 text-uppercase">Order Date</div>
                                        </th>
                                        <th scope="col" className="border-0 bg-light title-col">
                                            <div className="py-2 text-uppercase">No of items</div>
                                        </th>
                                        <th scope="col" className="border-0 bg-light title-col">
                                            <div className="py-2 text-uppercase">Grand Total</div>
                                        </th>
                                        <th scope="col" className="border-0 bg-light title-col">
                                            <div className="py-2 text-uppercase">Order Status</div>
                                        </th>
                                        <th scope="col" className="border-0 bg-light title-col">
                                            <div className="py-2 text-uppercase">Order Type</div>
                                        </th>
                                        <th scope="col" className="border-0 bg-light title-col">
                                            <div className="py-2 text-uppercase">Details</div>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        myorders.map((myorder, index) => {
                                            return (

                                                <tr key={index}>
                                                    <td className="align-middle"><strong><span>#Preorda-{myorder.order_Id}</span></strong></td>
                                                    <td className="align-middle"><strong><span>{myorder.orderPlacedDate}</span></strong></td>
                                                    <td className="align-middle"><strong><span>   {myorder.no_of_items} </span></strong></td>
                                                    <td className="align-middle"><strong><span className="WebRupee">&#x20B9;</span>{myorder.grand_total}</strong></td>
                                                    <td className="align-middle"><strong><span> {myorder.status} </span></strong></td>
                                                    <td className="align-middle"><strong><span> {myorder.ordertype} </span></strong></td>
                                                    <td className="align-middle"><strong><span>
                                                        <button className="badge checkout-custom rounded-pill" type="submit" onClick={e => viewMyOrderDetails(myorder.order_Id, index)}
                                                        >   +  </button>
                                                    </span></strong></td>
                                                    <td className="align-middle"><a href='#' className='btn btn-danger' onClick={e => cancelOrder(myorder.order_Id)}>Cancel</a></td>
                                                </tr>
                                            )
                                        })}


                                </tbody>

                            </table>{ORDER_DETAILS_HTML}

                        </div>
                    </div>

                </div>


            </div>
    }
    else {
        ORDER_HTML = <div style={{ minHeight: '85vh' }}>

            <div class="container-fluid d-flex justify-content-center align-items-center" style={{ minHeight: '55vh' }} >
                <div class="card p-3 text-center py-4 seller-card" id="sell_reg"><h3 className='text-center'>No Orders Found</h3>
                    <a href="/products" className="btn btn-danger rounded-pill py-2 d-md-block">
                        Place Your Order</a>
                </div>
            </div>
        </div>

    }

    return (
        <div>
            <Navbar />
            <section className="py-auto">
                {ORDER_HTML}

            </section>
        </div>

    )
}
export default MyOrders;