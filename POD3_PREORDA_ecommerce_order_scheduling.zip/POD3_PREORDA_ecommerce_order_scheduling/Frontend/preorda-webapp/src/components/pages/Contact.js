import React from "react";
import SellerNavbar from "../seller-nav/Seller-Header";
const Contact = () => {
  return (
    <div class="minh">
       <SellerNavbar/>
   
    <div className="container">
      <div className="py-4">
        <h1>Contact Page</h1>
        @PREORDA
      </div>
    </div>
    </div>
  );
};

export default Contact;
