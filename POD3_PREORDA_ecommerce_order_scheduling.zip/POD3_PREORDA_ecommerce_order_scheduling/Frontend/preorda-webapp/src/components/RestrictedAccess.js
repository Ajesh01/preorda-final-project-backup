import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";


function RestrictedAccess(props) {

    let userID = localStorage.getItem("user_id");
    const { Component } = props;
    const navigate = useNavigate();

    useEffect(() => {
        console.log("Coming....");
        console.log("userID", userID);
        console.log(typeof userID);

        if (userID == null) {
            console.log("ROLE inside if coming.. ");
            navigate('/login');
        }
    });
    return (
        <div>
            <Component />
        </div>
    )

}
export default RestrictedAccess;