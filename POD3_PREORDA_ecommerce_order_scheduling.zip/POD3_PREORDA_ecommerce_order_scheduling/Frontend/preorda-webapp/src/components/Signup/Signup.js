import React, { useState } from 'react';
import Navbar from '../Navbar/Navbar';
import './Signup.css'
import axios from 'axios';
import { useNavigate } from "react-router-dom";

function Signup() {

    const navigate = useNavigate();
    let [isLoaded, setIsLoaded] = useState(false);
    let [err, setErr] = useState(null);


    const handleClick = (e) => {
        e.preventDefault()
        // const customer = {
        //     first_name,
        //     last_name,
        //     username,
        //     password,
        //     // gender,
        //     // dob,
        //     phone_number,
        //     // user_id
        // }
        const login_creds = {
            username,
            password
        }
        var customer_details = {
            first_name,
            last_name,
            phone_number

        }

        let res;


        axios.post("http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/auth/register", login_creds)
            .then((response) => {
                res = response.data;

                if (response.status >= 400) {
                    throw new Error("User with this mail already exists!");
                }
                return response;
            })

            .then((response) => {
                if (response.data.user_id >= 0) {
                    console.log("success    ")
                    customer_details.user_id = response.data.user_id;

                    axios.post("http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/customer/register", customer_details)
                        .then((response) => {
                            console.log("success");
                            navigate("/login");

                            return response.data;
                        });
                }
                return response.data;

            }, (err) => {
                console.log(err);
                setErr(err);

                alert("User with this mail already exists!");
                setIsLoaded(true);
            });

        // console.log(customer)
    }
    const [first_name, setFirst_name] = useState('');
    const [last_name, setLast_name] = useState('');
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    // const [gender, setGender] = useState('');
    // const [dob, setDob] = useState('');
    const [phone_number, setPhone_number] = useState('');
    // const [user_id, setUser_id] = useState('');


    return (
        <div class="minh">
            <Navbar />
            <div style={{ minHeight: '85vh' }} data-aos="fade-down">
                <form>
                    <div class="container-fluid d-flex justify-content-center align-items-center" style={{ minHeight: '85vh' }}>

                        <div class="card p-3 text-center py-4 signup-card">
                            

                            <h4>Create account</h4>
                            <br/>

                            <div>
                                <span>Already have an account?</span>
                                <a href="/login" class="text-decoration-none"> Signin</a>
                            </div>
                            <div>
                                <span>Are you a Seller?</span>
                                <a href="/seller-signup" class="text-decoration-none"> Signup</a>
                            </div>
                   <hr/>


                            {/* <div class="mt-3 px-3">
                        <input class="form-control" placeholder="Username" value={}
          onChange={(e) => set(e.target.value)}/>
                    </div> */}



                            <div class="input-group px-3 mt-3">
                                <input type="text" class="form-control" placeholder="First Name" aria-label="Username" value={first_name}
                                    onChange={(e) => setFirst_name(e.target.value)} />
                                <span></span>
                                <input type="text" class="form-control" placeholder="Last Name" aria-label="Server" value={last_name}
                                    onChange={(e) => setLast_name(e.target.value)} />
                            </div>

                            <div class="mt-3 px-3">
                                <input class="form-control" placeholder="E-mail" value={username}
                                    onChange={(e) => setUsername(e.target.value)} />
                            </div>
                            <div class="mt-3 px-3">
                                <input type="text" id="inputPhno" class="form-control" placeholder="Phone Number" value={phone_number}
                                    onChange={(e) => setPhone_number(e.target.value)} />

                            </div>
                            <div class="mt-3 px-3">
                                <input type="password" id="inputPassword" class="form-control" placeholder="Create Password" value={password}
                                    onChange={(e) => setPassword(e.target.value)} />

                            </div>

                            <div class="mt-3 d-grid px-3">
                                <button class="btn btn-primary btn-block btn-signup text-uppercase" onClick={handleClick}>
                                    <span>Signup</span>

                                </button>
                            </div>

                            <div class="px-3">
                                <div class="mt-2 form-check d-flex flex-row">
                                    <input class="form-check-input" type="checkbox" value="" id="services" />
                                    <label class="form-check-label ms-2" for="services">
                                        I have read and agree to the terms.
                                    </label>
                                </div>
                            </div>
                        </div>


                    </div>
                </form>
            </div>
        </div>
    )

}


export default Signup