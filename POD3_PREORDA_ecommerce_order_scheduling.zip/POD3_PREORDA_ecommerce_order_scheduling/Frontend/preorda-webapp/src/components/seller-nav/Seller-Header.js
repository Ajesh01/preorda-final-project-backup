import React from "react";
import { Link, NavLink, useNavigate } from "react-router-dom";
import AuthService from "../services/auth.service";

function SellerNavbar() {
  let navigate = useNavigate();

  const handleClick = (e) => {
    navigate("/login");
    e.preventDefault();
    // console.log("login page : "+ username)
    AuthService.logout().then(
      () => {
        navigate("/login");
        window.location.reload();
      },
      (error) => {
        const resMessage =
          (error.response &&
            error.response.data &&
            error.response.data.message) ||
          error.message ||
          error.toString();
        //   setLoading(false);
        //   setMessage(resMessage);
      }
    );
  };
  return (
    <nav className="navbar navbar-expand-lg navbar-dark text-white bg-primary">
      <div className="container">
        <Link className="navbar-brand" to="/">
          PREORDA
        </Link>
        <button
          className="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse">
          <ul className="navbar-nav mr-auto">
            <li className="nav-item">
              <NavLink className="nav-link" exact to="/seller/home">
                Home
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink className="nav-link" exact to="/about">
                About
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink className="nav-link" exact to="/contact">
                Contact
              </NavLink>
            </li>
          </ul>
          <div class="collapse navbar-collapse justify-content-end">
            <NavLink className="nav-link" exact to="/seller/profile">
              My Profile
            </NavLink>

            <a href="/login">
              <button
                class="btn btn-outline-light ms-2 enlarge-quick float right"
                type="submit"
                onClick={handleClick}
              >
                Logout
              </button>
            </a>
          </div>
        </div>
      </div>
    </nav>
  );
}

export default SellerNavbar;
