import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useParams } from "react-router-dom";
import { useForm } from "react-hook-form";
import Form from "react-bootstrap/Form";
import SellerNavbar from "../seller-nav/Seller-Header";
import { useNavigate } from "react-router-dom";
var user = localStorage.getItem("user_id");

const SellerProfile = (e) => {
  const { seller_Id } = useParams();
  const navigate = useNavigate();
  function handleClick(e) {
    e.preventDefault();

    const Seller = {
      seller_name,
      phone_number,
      house_no,
      street,
      city,
      pincode,
      state,
      country,
    };
    console.log("sellers.seller_id", sellers.seller_id);
    fetch("http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/seller/edit-seller/" + sellers.seller_Id, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(sellers),
    }).then(() => {
      alert(" Profile updated successfully");
      navigate("/seller/home");
    });
  }
  const [sellers, setSellers] = useState({});
  const [seller_id, setSeller_id] = useState(false);
  const { setValue } = useForm({});

  function setData(fieldName, e) {
    console.log(fieldName);
    console.log(e.target.value);
    e.preventDefault();
    var data = sellers;
    data[fieldName] = e.target.value;
    setSellers({
      seller_Id: data["seller_Id"],
      seller_name: data["seller_name"],
      phone_number: data["phone_number"],
      //'email': data['email'],
      //'password': data['password'],
      house_no: data["house_no"],
      street: data["street"],
      city: data["city"],
      pincode: data["pincode"],
      state: data["state"],
      country: data["country"],
      user_id: user,
    });
    console.log(sellers);
  }

  useEffect(() => {
    // get user and set form fields
    fetch("http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/seller/" + user, {
      method: "GET",
      headers: { "Content-Type": "application/json" },
    }).then(async (response) => {
      const data = await response.json();
      console.log("User Profile", data);
      //const fields = ['customer_Id', 'first_name', 'last_name', 'email', 'password', 'phone_number'];
      const fields = [
        "seller_Id",
        "seller_name",
        "phone_number",
        "house_no",
        "street",
        "city",
        "pincode",
        "state",
        "country",
      ];
      fields.forEach((field) => setValue(field, data[field]));

      setSellers(data);
      console.log(sellers);
    });
  }, []);
  //  const [product_id, setProduct_id] = useState('')
  const [seller_name, setSeller_name] = useState("");
  const [phone_number, setPhone_number] = useState("");
  const [house_no, setHouse_no] = useState("");
  const [street, setStreet] = useState("");
  const [city, setCity] = useState("");
  const [pincode, setPincode] = useState("");
  const [state, setState] = useState("");
  const [country, setountry] = useState("");
  //const [email, setEmail] = useState('')
  //const [password, setPassword] = useState('')

  //  const [product_id, setProduct_id] = useState('')
  return (
    <div class="minh">
      <SellerNavbar />
      <div className="container card checkout-card">
        <h2 className="text-center">My Profile </h2>
        <hr className="line" />
        <div className="row">
          <div className="card col-md-6 offset-md-3 offset-md-3">
            <div className="card-body">
              <form>
                <div className="form-group mb-2">
                  <label className="form-label"> Seller Name :</label>
                  <input
                    type="text"
                    name="seller_name"
                    placeholder={sellers.seller_name}
                    className="form-control"
                    value={sellers.seller_name}
                    onChange={(e) => setData("seller_name", e)}
                  ></input>
                </div>
                <div className="form-group mb-2">
                  <label className="form-label"> Phone number :</label>
                  <input
                    type="text"
                    name="phone_number"
                    placeholder={sellers.phone_number}
                    className="form-control"
                    value={sellers.phone_number}
                    onChange={(e) => setData("phone_number", e)}
                  ></input>
                </div>

                <div className="form-group mb-2">
                  <label className="form-label"> House_no :</label>
                  <input
                    type="text"
                    name="phone_number"
                    placeholder={sellers.house_no}
                    className="form-control"
                    value={sellers.house_no}
                    onChange={(e) => setData("house_no", e)}
                  ></input>
                </div>

                <div className="form-group mb-2">
                  <label className="form-label"> Street :</label>
                  <input
                    type="text"
                    name="street"
                    placeholder={sellers.street}
                    className="form-control"
                    value={sellers.street}
                    onChange={(e) => setData("street", e)}
                  ></input>
                </div>
                <div className="form-group mb-2">
                  <label className="form-label"> City :</label>
                  <input
                    type="text"
                    name="city"
                    placeholder={sellers.city}
                    className="form-control"
                    value={sellers.city}
                    onChange={(e) => setData("city", e)}
                  ></input>
                </div>
                <div className="form-group mb-2">
                  <label className="form-label"> Pincode :</label>
                  <input
                    type="text"
                    name="pincode"
                    placeholder={sellers.pincode}
                    className="form-control"
                    value={sellers.pincode}
                    onChange={(e) => setData("pincode", e)}
                  ></input>
                </div>
                <div className="form-group mb-2">
                  <label className="form-label"> State :</label>
                  <input
                    type="text"
                    name="state"
                    placeholder={sellers.state}
                    className="form-control"
                    value={sellers.state}
                    onChange={(e) => setData("state", e)}
                  ></input>
                </div>

                <div className="form-group mb-2">
                  <label className="form-label"> Country :</label>
                  <input
                    type="text"
                    name="country"
                    placeholder={sellers.country}
                    className="form-control"
                    value={sellers.country}
                    onChange={(e) => setData("country", e)}
                  ></input>
                </div>

                <table className="table">
                  <td className="align-middle">
                    <button
                      className="btn btn-primary"
                      onClick={(e) => handleClick(e)}
                    >
                      Submit{" "}
                    </button>
                  </td>
                  <td className="align-middle">
                    <Link to="/" className="btn btn-danger">
                      {" "}
                      Cancel{" "}
                    </Link>
                  </td>
                </table>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SellerProfile;
