import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import SellerNavbar from "../seller-nav/Seller-Header";
import { Navbar } from "react-bootstrap";
import EditProduct from "../seller-inventory/Edit-Product-Inventory-Page";
import axios from "axios";
import "./seller-home.css";
var user_id = localStorage.getItem("user_id");
function SellerHome() {
  const [users, setUser] = useState([]);
  const [sellerproducts, setsellerproducts] = useState([]);

  useEffect(() => {
    let mounted = true;
    // console.log(user_id);
    fetch("http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/inventory/products/user/" + user_id, {
      method: "GET",
      headers: { "Content-Type": "application/json" },
      // body: JSON.stringify(sellerproducts)
    }).then(async (response) => {
      const data = await response.json();
      console.log(data);
      if (mounted) setsellerproducts(data);
    });
    return () => (mounted = false);
  }, []);

  function handleSubmit(id) {
    console.log(id);
    fetch("http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/inventory/del-products/" + id, {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      // body: JSON.stringify(sellerproducts)
    }).then(() => {
      alert("product deleted");
      fetch("http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/inventory/products", {
        method: "GET",
        headers: { "Content-Type": "application/json" },
        // body: JSON.stringify(sellerproducts)
      }).then(async (response) => {
        const data = await response.json();
        console.log(data);
        //if(mounted)
        setsellerproducts(data);
      });
    });
  }
  return (
    <div class="minh">
      {" "}
      <SellerNavbar />
      <div>
        <h2 className="text-center"> Products page</h2>
        <Link to="/seller/add-product" className="btn btn-primary mb-2">
          {" "}
          Add Products{" "}
        </Link>
        <div className="table-responsive-sm">
          <table className="table table-bordered table-striped ">
            <thead>
              <tr>
                <th> Product Id </th>
                <th>Image</th>
                <th> Product Name</th>
                <th> Product Description</th>
                <th> Quantity </th>
                <th> Price</th>
                <th> Product Brand</th>
                <th> Category</th>
                <th> Actions </th>
              </tr>
            </thead>

            <tbody>
              {sellerproducts.map((sellerproduct) => (
                <tr key={sellerproduct.id}>
                  <td> {sellerproduct.id} </td>
                  <td>
                    <img height="80" width="80" src={sellerproduct.imgSrc} />{" "}
                  </td>
                  <td> {sellerproduct.name} </td>
                  <td> {sellerproduct.description} </td>
                  <td> {sellerproduct.quantity} </td>
                  <td> {sellerproduct.price}</td>
                  <td> {sellerproduct.brand} </td>
                  <td> {sellerproduct.category} </td>
                  <td>
                    <Link
                      className="btn btn-info btn-primary"
                      to={`/seller/edit-products/${sellerproduct.id}`}
                    >
                      Update
                    </Link>
                    <button
                      className="btn btn-danger"
                      onClick={(e) => handleSubmit(sellerproduct.id)}
                      style={{ marginLeft: "10px" }}
                    >
                      {" "}
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default SellerHome;

export function getProducts() {
  fetch("http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/seller/products", {
    method: "GET",
    headers: { "Content-Type": "application/json" },
    // body: JSON.stringify(sellerproducts)
  }).then((response) => {
    response.json();
  });
}

export function handleClick(id) {
  console.log(id);
  fetch("http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/inventory/del-products/" + id, {
    method: "DELETE",
    headers: { "Content-Type": "application/json" },
    // body: JSON.stringify(sellerproducts)
  }).then(() => {
    alert("product deleted");
    fetch("http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/inventory/products", {
      method: "GET",
      headers: { "Content-Type": "application/json" },
      // body: JSON.stringify(sellerproducts)
    }).then((data) => this.setsellerproducts(data));
  });
}
