import React, { Component } from 'react';
// import './Footer.css';


class Footer extends Component{
    render(){
        return (
            <footer class="container">
            <p class="float-end cr"><a href="#">Back to top</a></p>
            <p class="cr">&copy; 2017–2021 Company, Inc. &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
          </footer>
        )
    }
}

export default Footer