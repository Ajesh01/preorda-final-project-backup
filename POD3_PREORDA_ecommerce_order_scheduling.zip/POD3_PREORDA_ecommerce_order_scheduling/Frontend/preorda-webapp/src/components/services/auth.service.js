import axios from "axios";
import setUserState from "../../App"

const API_URL = "http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/auth/";
// const register = (username, email, password) => {
//   return axios.post(API_URL + "signup", {
//     username,
//     email,
//     password,
//   });
// };
const login = (username, password) => {
  console.log("logging in! " + username);
  return axios
    .post(API_URL + "authenticate", {
      username,
      password,
    })
    .then((response) => {
      if (response.data.token) {
        // localStorage.setItem("user", "aa");
        // setUserState('myState');

        console.log("login success!" + response.data);
        localStorage.setItem("token", JSON.stringify(response.data.token));
        localStorage.setItem("username", JSON.stringify(response.data.uname));
        localStorage.setItem("user_id", JSON.stringify(response.data.uid));
        localStorage.setItem("role", JSON.stringify(response.data.role));

        return response;

      }
      return response;
    });
};
const logout = () => {
  localStorage.removeItem("token");
  localStorage.removeItem("username");
  localStorage.removeItem("user_id");
  localStorage.removeItem("role");
  //   setUserState(null);

};

const get_login_status = () => {
  var flag = JSON.parse(localStorage.getItem("token"));
  console.log(flag)
  if (flag != null) {
    console.log("not null token")
    return 1;
  }
  return 0;
};

const getCurrentUser = () => {
  return JSON.parse(localStorage.getItem("token"));
};
const AuthService = {
  //   register,
  login,
  logout,
  getCurrentUser,
  get_login_status
};
export default AuthService;
