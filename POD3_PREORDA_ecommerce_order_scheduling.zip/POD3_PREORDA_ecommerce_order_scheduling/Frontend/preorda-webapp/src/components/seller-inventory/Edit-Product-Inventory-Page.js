import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useParams } from "react-router-dom";
import { useForm } from "react-hook-form";

import SellerNavbar from "../seller-nav/Seller-Header";

const EditProduct = (e) => {
  const navigate = useNavigate();
  const { id } = useParams();

  function handleClick(e) {
    e.preventDefault();
    const sellerProduct = {
      name,
      description,
      price,
      quantity,
      brand,
      category,
      imgSrc,
    };
    console.log(sellerproducts.id);
    fetch(
      "http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/inventory/edit-products/" + sellerproducts.id,
      {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(sellerproducts),
      }
    ).then(() => {
      alert(" product edited successfully");
      navigate("/seller/home");
    });
  }
  const [sellerproducts, setsellerproducts] = useState({});
  const [product_id, setProduct_id] = useState(false);
  const { setValue } = useForm({});

  function setData(fieldName, e) {
    console.log(fieldName);
    console.log(e.target.value);
    e.preventDefault();
    setsellerProductData(fieldName, e.target.value);
    console.log(sellerproducts);
  }

  function setsellerProductData(fieldName, value) {
    var data = sellerproducts;
    data[fieldName] = value;
    setsellerproducts({
      id: data["id"],
      name: data["name"],
      description: data["description"],
      price: data["price"],
      quantity: data["quantity"],
      brand: data["brand"],
      category: data["category"],
      imgSrc: data["imgSrc"],
    });
    console.log(sellerproducts);
  }

  function onFileUpload(e) {
    var reader = new FileReader();
    reader.onload = (e) => {
      var base64img = reader.result;
      setsellerProductData("imgSrc", base64img);
      //setImgName(e.target.files[0].name)
      console.log(sellerproducts);
    };

    reader.readAsDataURL(e.target.files[0]);
  }

  useEffect(() => {
    // get user and set form fields
    fetch("http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/inventory/products/" + id, {
      method: "GET",
      headers: { "Content-Type": "application/json" },
    }).then(
      //(
      // product) => {
      //     const fields = ['id','product_name', 'description', 'price', 'quantity', 'brand'];
      //     fields.forEach(field => setValue(field, product[field]));
      //     setsellerproducts(product);
      //     console.log(sellerProduct)
      // }
      async (response) => {
        const data = await response.json();
        console.log(data);
        const fields = [
          "id",
          "name",
          "description",
          "price",
          "quantity",
          "brand",
        ];
        fields.forEach((field) => setValue(field, data[field]));

        setsellerproducts(data);
        console.log(sellerproducts);
      }
    );
  }, []);
  //  const [product_id, setProduct_id] = useState('')
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [quantity, setQuantity] = useState("");
  const [brand, setBrand] = useState("");
  const [category, setCategory] = useState("");
  const [imgSrc, setImgSrc] = useState("");
  return (
    <div class="minh">
      <SellerNavbar />
      <div className="container">
        <h2 className="text-center">Edit Products </h2>
        <div className="row">
          <div className="card col-md-6 offset-md-3 offset-md-3">
            <div className="card-body">
              <form>
                <div className="form-group mb-2">
                  <label className="form-label"> Product Name :</label>
                  <input
                    type="text"
                    placeholder="Enter Product Name"
                    name="name"
                    className="form-control"
                    value={sellerproducts.name}
                    onChange={(e) => setData("name", e)}
                  ></input>
                </div>
                <div className="form-group mb-2">
                  <label className="form-label">
                    {" "}
                    Description about the product:
                  </label>
                  <input
                    type="text"
                    placeholder="Enter product description"
                    name="description"
                    className="form-control"
                    value={sellerproducts.description}
                    onChange={(e) => setData("description", e)}
                  ></input>
                </div>
                <div className="form-group mb-2">
                  <label className="form-label"> Price :</label>
                  <input
                    type="text"
                    placeholder="Enter product price"
                    name="price"
                    className="form-control"
                    value={sellerproducts.price}
                    onChange={(e) => setData("price", e)}
                  ></input>
                </div>

                <div className="form-group mb-2">
                  <label className="form-label"> Quantity :</label>
                  <input
                    type="number"
                    placeholder="Enter product quantity"
                    name="quantity"
                    className="form-control"
                    value={sellerproducts.quantity}
                    onChange={(e) => setData("quantity", e)}
                  ></input>
                </div>

                <div className="form-group mb-2">
                  <label className="form-label">Product Brand:</label>
                  <input
                    type="text"
                    placeholder="Enter product brand"
                    name="brand"
                    className="form-control"
                    value={sellerproducts.brand}
                    onChange={(e) => setData("brand", e)}
                  ></input>
                </div>

                <div className="form-group mb-2">
                  <label className="form-label">Category:</label>
                  <select
                    value={sellerproducts.category}
                    onChange={(e) => setData("category", e)}
                    className="btn btn-sm btn-outline-secondary dropdown-toggle form-control"
                  >
                    <option value="" disabled selected>
                      Select the category
                    </option>
                    <option value="Electronics">Electronics</option>
                    <option value="Groceries">Groceries</option>
                    <option value="Household_Supplies">
                      Household Supplies
                    </option>
                    <option value="Clothing">Clothing</option>
                  </select>
                </div>
                <div className="form-group mb-2">
                  <label className="form-label">Image</label>
                  <input
                    type="file"
                    // id={imgName}
                    src={sellerproducts.imgSrc}
                    onChange={(e) => onFileUpload(e)}
                  ></input>
                  <img height="200" src={sellerproducts.imgSrc} />
                </div>
                <button
                  className="btn btn-primary"
                  onClick={(e) => handleClick(e)}
                >
                  Submit{" "}
                </button>
                <Link to="/seller/home" className="btn btn-danger">
                  {" "}
                  Cancel{" "}
                </Link>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EditProduct;
