import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

import SellerNavbar from "../seller-nav/Seller-Header";
var user_id = localStorage.getItem("user_id");
const AddProduct = () => {
  const navigate = useNavigate();
  let [isLoaded, setIsLoaded] = useState(false);
  let [err, setErr] = useState(null);
  const handleClick = (e) => {
    e.preventDefault();
    const sellerProduct = {
      name,
      description,
      price,
      quantity,
      brand,
      category,
      //imgName,
      imgSrc,
    };
    console.log(sellerProduct);
    fetch("http://pod3apigateway-env.eba-veztuitz.eu-west-3.elasticbeanstalk.com/inventory/products/save/" + user_id, {
      method: "POST",
      headers: { "Content-Type": "application/json" },

      body: JSON.stringify(sellerProduct),
    })
      .then((res) => {
        // Unfortunately, fetch doesn't send (404 error)
        // into the cache itself
        // You have to send it, as I have done below
        if (res.status >= 400) {
          throw new Error("Product already present!");
        }
        //return
      })
      .then(
        () => {
          setIsLoaded(true);
          alert("New product added");
          navigate("/seller/home");
        },
        (err) => {
          console.log(err);
          setErr(err);
          alert("Product already present");
          navigate("/seller/home");
          setIsLoaded(true);
        }
      );
  };
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [quantity, setQuantity] = useState("");
  const [brand, setBrand] = useState("");
  const [category, setCategory] = useState("");
  const [imgName, setImgName] = useState("");
  const [imgSrc, setImgSrc] = useState("");

  function onFileUpload(e) {
    var reader = new FileReader();
    reader.onload = (e) => {
      var base64img = reader.result;
      setImgSrc(base64img);
      // setImgName(e.target.files[0].name);
    };
    if (e.target.files[0]) {
      reader.readAsDataURL(e.target.files[0]);
    }
  }

  return (
    <div class="minh">
      <SellerNavbar />
      <div className="container">
        <h2 className="text-center">Add Products </h2>
        <div className="row">
          <div className="card col-md-6 offset-md-3 offset-md-3">
            <div className="card-body">
              <form>
                <div className="form-group mb-2">
                  <label className="form-label"> Product Name :</label>
                  <input
                    type="text"
                    placeholder="Enter Product Name"
                    name="product_name"
                    className="form-control"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  ></input>
                </div>
                <div className="form-group mb-2">
                  <label className="form-label">
                    {" "}
                    Description about the product:
                  </label>
                  <input
                    type="text"
                    placeholder="Enter product description"
                    name="description"
                    className="form-control"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                  ></input>
                </div>
                <div className="form-group mb-2">
                  <label className="form-label"> Price :</label>
                  <input
                    type="text"
                    placeholder="Enter product price"
                    name="firstName"
                    className="form-control"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                  ></input>
                </div>

                <div className="form-group mb-2">
                  <label className="form-label"> Quantity :</label>
                  <input
                    type="number"
                    placeholder="Enter product quantity"
                    name="quantity"
                    className="form-control"
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                  ></input>
                </div>

                <div className="form-group mb-2">
                  <label className="form-label">Product Brand:</label>
                  <input
                    type="text"
                    placeholder="Enter product brand"
                    name="productbrand"
                    className="form-control"
                    value={brand}
                    onChange={(e) => setBrand(e.target.value)}
                  ></input>
                </div>

                <div className="form-group mb-2">
                  <label className="form-label">Category:</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="btn btn-sm btn-outline-secondary dropdown-toggle form-control"
                  >
                    <option value="" disabled selected>
                      Select the category
                    </option>
                    <option value="Electronics">Electronics</option>
                    <option value="Groceries">Groceries</option>
                    <option value="Household_Supplies">
                      Household Supplies
                    </option>
                    <option value="Clothing">Clothing</option>
                  </select>
                </div>

                <div className="form-group mb-2">
                  <label className="form-label">Image</label>
                  <input
                    type="file"
                    id={imgName}
                    src={imgSrc}
                    onChange={(e) => onFileUpload(e)}
                  ></input>
                  <img height="200" id={imgName} src={imgSrc} />
                </div>

                <button className="btn btn-primary" onClick={handleClick}>
                  Submit{" "}
                </button>
                <Link to="/seller/home" className="btn btn-danger">
                  {" "}
                  Cancel{" "}
                </Link>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddProduct;
