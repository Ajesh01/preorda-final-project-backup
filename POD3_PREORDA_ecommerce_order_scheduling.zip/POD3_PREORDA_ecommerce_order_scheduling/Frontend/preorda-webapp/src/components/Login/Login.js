import React, { useState } from 'react';
import Navbar from '../Navbar/Navbar';
import './Login.css'
import AuthService from "../services/auth.service";
import { useNavigate } from 'react-router-dom';
import { Navigate } from 'react-router-dom';

import Home from '../../components/Home/Home';
// import { Redirect } from "react-router-dom";


function Login() {

    let navigate2 = useNavigate();
    let [isLoaded, setIsLoaded] = useState(false);
    let [err, setErr] = useState(null);

    var login_flag = AuthService.get_login_status()



    // onPageLoad();
    //  if (login_flag == 1){
    //     console.log("logged in!");

    //     navigate("/");

    //     //   window.location.reload();
    //     }
    //     else{
    //         console.log("not logged in!")
    //     }

    // }




    const handleClick = (e) => {
        e.preventDefault()
        // console.log("login page : "+ username)
        AuthService.login(username, password)
            .then((response) => {
                // console.log(response.status);
                if (response.status >= 400) {
                    throw new Error("Invalid Mailid or Password!");
                }
                return response.data.role;
            })
            .then(
                (role) => {


                    if (role == "seller") {
                        navigate2("/seller/home");
                    }
                    else {
                        navigate2("/");
                    }

                    window.location.reload();
                },
                (error) => {

                    setErr(error);
                    alert("Invalid Email address or Password!");
                    setIsLoaded(true);
                }
            );
    }


    const [username, setUsername] = useState('');
    // const [username, setemail] = useState('');
    const [password, setPassword] = useState('');

    // return (

    return login_flag ? <Navigate to="/" /> : (
        <div class="minh">
            <Navbar />
            <div style={{ minHeight: '85vh' }}>

                <div class="container-fluid d-flex justify-content-center align-items-center" style={{ minHeight: '85vh' }}>

                    <div class="card p-3 text-center py-4 px-3 mt-3 login-card">
                        <h4 class="fw-bold">Login</h4>
                        <div>
                            <span>Don’t have an account?</span>
                            <a href="/signup" class="text-decoration-none"> Signup</a>
                        </div>

                        <hr />
                        <div class="d-inline-flex p-3 pb-1">
                            <label for="email" class="form-label fw-bold"  >email address</label>
                        </div>

                        <div class=" px-3">

                            <input class="form-control" id="email" placeholder="name@example.com" value={username}
                                onChange={(e) => setUsername(e.target.value)} />
                        </div>


                        <div class="d-inline-flex p-3 pb-1">
                            <label for="inputPassword" class="form-label pl-2 pr-0 fw-bold" >password</label>

                        </div>
                        <div class=" px-3">
                            <input type="password" id="inputPassword" class="form-control" placeholder="" value={password}
                                onChange={(e) => setPassword(e.target.value)} />
                        </div>

                        <div class="mt-3 d-grid px-3">
                            <button class="btn btn-primary btn-block btn-signup text-uppercase" onClick={handleClick}>
                                <span >Signin</span>

                            </button>
                        </div>


                    </div>


                </div></div>
        </div>

    )

}


export default Login