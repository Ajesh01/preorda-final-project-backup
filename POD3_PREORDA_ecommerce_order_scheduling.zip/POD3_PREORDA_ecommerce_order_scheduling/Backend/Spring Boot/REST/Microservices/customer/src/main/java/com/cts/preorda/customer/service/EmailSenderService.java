package com.cts.preorda.customer.service;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.cts.preorda.customer.model.OrderDetails;
import com.cts.preorda.customer.repository.AddressRepo;
import com.cts.preorda.customer.repository.CustomerRepository;
import com.cts.preorda.customer.repository.OrderDetailsRepository;
import com.cts.preorda.customer.repository.OrderRepository;

@Service
public class EmailSenderService implements EmailSenderInterf{
	
	@Autowired
	private JavaMailSender mailSender;
	
	@Autowired
	private  AddressRepo addressRepo;
	
	@Autowired
	private OrderRepository orderRepo;
	
	@Autowired
	private OrderDetailsRepository orderDetailsRepo;
	
	@Autowired
	private CustomerRepository customerRepo; 
	
	List li;
	
	public void sendSimpleEmail(String toEmail) {
		SimpleMailMessage message = new SimpleMailMessage();
		
		
		
		message.setFrom("ecommercesitepreorda@gmail.com");
		message.setTo(toEmail);
		message.setText("Thank you for shopping with PREORDA! Looking Forward for many more orders with you:)");
		message.setSubject("Order confirmation");
		
		mailSender.send(message);
		System.out.println("Message sent...");
	}
	
	public void sendSimpleEmailWithAttachment(String toEmail, String first_name, String last_name, String grand_total, List<OrderDetails> orderDetails) throws MessagingException, IOException {
		MimeMessage mimeMessage = mailSender.createMimeMessage();
		
		MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, true);
		
		System.out.println("String toEmail, String first_name, String last_name, String grand_total..."+
		toEmail +" " +first_name +" " +grand_total); 
		
		mimeMessageHelper.setFrom("ecommercesitepreorda@gmail.com");
		mimeMessageHelper.setTo(toEmail);
		mimeMessageHelper.setText("Thank you for shopping with PREORDA! Looking Forward for many more orders with you:)");
		mimeMessageHelper.setSubject("Order confirmation");
		//mimeMessageHelper.setCc("haripulluru05@gmail.com");
		
		FileSystemResource fileSystem = new FileSystemResource(new File("src/main/resources/Invoice.html"));
		
		li = orderDetails;
		
		File htmlTemplateFile = new File("src/main/resources/Invoice.html");
		String htmlString = FileUtils.readFileToString(htmlTemplateFile);

//		String title = "Order Confirmation";
//		String htmlbody = "Thank you for shopping with PREORDA.";
//		htmlString = htmlString.replace("$title", title);
//		htmlString = htmlString.replace("$body", htmlbody);
		htmlString = htmlString.replace("${first_name}", first_name);
		htmlString = htmlString.replace("${last_name}", last_name);
		htmlString = htmlString.replace("${username}", toEmail);
		htmlString = htmlString.replace("${grand_total}", grand_total);
//		htmlString = htmlString.replace("$title", title);
//		htmlString = htmlString.replace("$body", htmlbody);
		
		//ModelAndView model = EmailSenderController.mailGeneration(first_name,last_name,grand_total);
		
	    for(int i=0;i<orderDetails.size();i++) {
	    	int ind = htmlString.indexOf("<td id = \"ending\"");
	    	String newStr = "<tr class=\"item\">\r\n"
	    			+ "                <td id = \"ending\" style=\"padding: 5px;vertical-align: top;border-bottom: 1px solid #eee;\">\r\n"
	    			+ "                    ${itemname}\r\n"
	    			+ "                </td>\r\n"
	    			+ "                \r\n"
	    			+ "                <td style=\"padding: 5px;vertical-align: top;border-bottom: 1px solid #eee;\">\r\n"
	    			+ "                    ${quantity}\r\n"
	    			+ "                </td>\r\n"
	    			+ "                <td style=\"padding: 5px;vertical-align: top;text-align: right;border-bottom: 1px solid #eee;\">\r\n"
	    			+ "                    ${price}\r\n"
	    			+ "                 </td>\r\n"
	    			+ "            </tr>";
	    	
	    	StringBuffer str = new StringBuffer(htmlString);
	    	htmlString = str.insert(ind, newStr).toString();
	    	String itemname = orderDetails.get(i).getProduct_name();
	    	String quantity = ""+orderDetails.get(i).getQuantity();
	    	String price = ""+orderDetails.get(i).getSubtotal();
	    	
	    	htmlString = htmlString.replace("${itemname}", itemname);
	    	htmlString = htmlString.replace("${quantity}", quantity);
	    	htmlString = htmlString.replace("${price}", price);
	    	//str.insert(, )
	    }
	    
	    

		File newHtmlFile = new File(".\\src\\main\\resources\\tosend.html");
		FileUtils.writeStringToFile(newHtmlFile, htmlString);
		
		mimeMessageHelper.addAttachment(htmlTemplateFile.getName(), newHtmlFile);
		
		mailSender.send(mimeMessage);
		
		System.out.println("Message sent.......");
		
	}
	
	public List getOrderDetails() {
		return li;
	}

}
