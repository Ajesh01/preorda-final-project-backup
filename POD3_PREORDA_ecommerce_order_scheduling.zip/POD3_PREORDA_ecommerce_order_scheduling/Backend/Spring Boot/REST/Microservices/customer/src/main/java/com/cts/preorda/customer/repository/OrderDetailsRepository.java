package com.cts.preorda.customer.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cts.preorda.customer.model.OrderDetails;

@Repository

public interface OrderDetailsRepository extends JpaRepository<OrderDetails, Integer> {
	public List<OrderDetails> findByOrderid(int orderid);

	@Transactional
	@Modifying
	@Query(value="delete from order_details where orderid = :orderid and orderdetails_Id > 0",nativeQuery = true)
	
	void delete_order_details(@Param("orderid") int orderid);
}