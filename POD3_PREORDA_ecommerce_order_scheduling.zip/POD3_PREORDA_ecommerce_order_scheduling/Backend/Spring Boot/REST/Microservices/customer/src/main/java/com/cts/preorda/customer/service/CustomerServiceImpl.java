package com.cts.preorda.customer.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.preorda.customer.model.Customer;
import com.cts.preorda.customer.model.Products;
import com.cts.preorda.customer.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService {
	
	private static List<Customer> customers = new ArrayList<>();

	@Autowired
	CustomerRepository customerRepo;

	@Override
	public Customer storeUserDetails(Customer customer) {	
		System.out.println(customer);

		//String cus_email= customer.getEmail

		

		return customerRepo.save(customer);

	}
	@Override
	public void update(int customer_Id, Customer customer) {
		
		customers = customers.stream().map(b ->{
			if(b.getCustomer_Id()==customer_Id) {
				b.setFirst_name(customer.getFirst_name());
				b.setLast_name(customer.getLast_name());
				//b.setEmail(customer.getEmail());
				//b.setPassword(customer.getPassword());
				b.setPhone_number(customer.getPhone_number());
			}
			return b;
		}).collect(Collectors.toList());
		 customerRepo.save(customer);
	}
	public Customer getCustomer(int customer_Id) {
		Customer customer = customerRepo.getCustomer(customer_Id);
		return customer;
	}
}