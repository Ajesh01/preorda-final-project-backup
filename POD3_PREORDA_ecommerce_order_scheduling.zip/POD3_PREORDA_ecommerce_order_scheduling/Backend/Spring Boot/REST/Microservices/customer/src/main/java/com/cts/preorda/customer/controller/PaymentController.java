package com.cts.preorda.customer.controller;

import org.json.JSONObject;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.preorda.customer.model.PaymentRequest;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;

@RestController
@RequestMapping("/payment")
@CrossOrigin
public class PaymentController {

	@PostMapping("/getorderid")
	public PaymentRequest processPlaceOrder(@RequestBody String amount) {
		PaymentRequest	details = new PaymentRequest();
		try {
			int amount2 = Integer.parseInt(amount);
			RazorpayClient razorpayClient = new RazorpayClient("rzp_test_uTxY14toaja9lC", "3eM3ikDsM9hYYaxID6hFwsg4");
			JSONObject options = new JSONObject();
			options.put("amount", amount2);
			options.put("currency", "INR");
//			options.put("receipt", "txn_1");
			Order order = razorpayClient.orders.create(options);
			System.out.println("get payment id triggered!");
			details.setOrder_id(order.get("id"));
			return details;			
			} catch (Exception e) {
			  // Handle Exception
			  System.out.println(e.getMessage());
			  return details;
			}
	    
	}
	
}
