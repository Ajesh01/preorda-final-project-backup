package com.cts.preorda.customer.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cts.preorda.customer.model.Addresses;

public interface AddressRepo extends JpaRepository<Addresses,Integer> {

		@Query(value="select count(user) from addresses where user = :user",nativeQuery = true)
		int countByCustomer_id(@Param("user") int user);
	
	@Query(value="select * from addresses where user = :user",nativeQuery = true)
	List<Addresses> getAddressList(@Param("user") int user);
	
//	@Query(value="select * from customer where username = :email",nativeQuery = true)
//	Customer getCustomerById(@Param("email") String email);
	
}


