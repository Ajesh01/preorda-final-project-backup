package com.cts.preorda.customer.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice

public class ExceptionAdvisor {
	
	@ExceptionHandler(ApplicationException.class)
    public ResponseEntity<ExceptionResponse> handleApplicationException(
    		ApplicationException ex) {
		ExceptionResponse resp = new ExceptionResponse();
		
       resp.setErrorMessage(ex.getErrorMessage());
       resp.setErrorCode(ex.getErrorCode());

        return new ResponseEntity<ExceptionResponse>(resp, HttpStatus.INTERNAL_SERVER_ERROR);
    }

}
