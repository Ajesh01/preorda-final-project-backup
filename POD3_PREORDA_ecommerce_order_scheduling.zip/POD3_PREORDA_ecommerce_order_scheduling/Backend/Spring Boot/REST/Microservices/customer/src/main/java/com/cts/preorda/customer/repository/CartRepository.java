package com.cts.preorda.customer.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
//import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cts.preorda.customer.model.Cart;

@Repository

public interface CartRepository extends JpaRepository<Cart, Integer>{

	public List<Cart> findByUser(int user_id);
	public String deleteByUser(int user_id);
	
	
	@Transactional
	@Modifying
	@Query(value="delete from cart where user = :user and cart_id > 0",nativeQuery = true)
	
	void delete_user_cart(@Param("user") int user);
}
