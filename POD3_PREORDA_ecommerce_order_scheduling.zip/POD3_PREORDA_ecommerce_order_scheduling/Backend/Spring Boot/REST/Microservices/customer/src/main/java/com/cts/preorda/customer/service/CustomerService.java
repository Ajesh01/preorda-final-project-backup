package com.cts.preorda.customer.service;

import com.cts.preorda.customer.model.Customer;

public interface CustomerService {
	public Customer storeUserDetails(Customer customer);
	public void update(int customer_Id, Customer customer);
	public Customer getCustomer(int customer_Id);

}
