package com.cts.preorda.customer.service;

import java.io.IOException;
import java.util.List;

import javax.mail.MessagingException;

import com.cts.preorda.customer.model.OrderDetails;

public interface EmailSenderInterf {

	public void sendSimpleEmailWithAttachment(String toEmail, String first_name, String last_name, String grand_total, List<OrderDetails> orderDetails) throws MessagingException, IOException;
}
