package com.cts.preorda.customer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.preorda.customer.model.Customer;
import com.cts.preorda.customer.model.Products;
import com.cts.preorda.customer.service.CustomerService;

@RestController
@RequestMapping("/customer")
@CrossOrigin
public class CustomerController {
	
	@Autowired
	CustomerService customerService;
	
	

	@PostMapping("/register")
	public String processRegister(@RequestBody Customer customer) {

		this.customerService.storeUserDetails(customer);
		
		return "register success";
	}
	@PutMapping("/edit-customer/{customer_Id}")  
	public Customer update(@RequestBody Customer customer,@PathVariable("customer_Id") int customer_Id)   
	{  
    this.customerService.update(customer_Id, customer);  
    return customer;
	}  
	@GetMapping("/{customer_Id}")
	public Customer getCustomer(@PathVariable int customer_Id) {
		return customerService.getCustomer(customer_Id);
	}
	
}