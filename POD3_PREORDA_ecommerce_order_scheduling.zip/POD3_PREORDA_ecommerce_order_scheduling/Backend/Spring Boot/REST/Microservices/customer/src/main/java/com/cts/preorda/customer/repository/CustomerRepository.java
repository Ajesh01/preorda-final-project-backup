package com.cts.preorda.customer.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.preorda.customer.model.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Integer>{

	
	@Query(value = "select * from customer where user_id = :uid", nativeQuery = true)
	Customer get_user_details_with_uid(@Param("uid")int uid);

	
	@Query(value="select * from customer where user_id = :uid",nativeQuery = true)
	Customer getCustomer(@Param("uid") int uid);
	

}
