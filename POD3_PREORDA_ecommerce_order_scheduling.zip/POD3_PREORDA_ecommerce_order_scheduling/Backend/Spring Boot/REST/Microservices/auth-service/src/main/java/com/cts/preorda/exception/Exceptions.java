package com.cts.preorda.exception;


public enum Exceptions {
	MAIL_EXIST("APP001","User Mail ID already exists!");
	public final String errorCode;
	public final String errorMessage;
	
	private Exceptions(String errorCode, String errorMessage) {
		this.errorCode=errorCode;
		this.errorMessage=errorMessage;
	}

}
