package com.cts.preorda;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserRegistrationAndLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
