package com.cts.preorda.seller.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.preorda.seller.model.Inventory;
import com.cts.preorda.seller.model.Products;

public interface InventoryRepository extends JpaRepository<Inventory, Integer>{

	//public void deleteByProduct_Id(int id);
	
	//public List<Products> findByName(String name);
	public Inventory findById(int inventory_id);
	//public void saveorupdate(Inventory inventory);
}
