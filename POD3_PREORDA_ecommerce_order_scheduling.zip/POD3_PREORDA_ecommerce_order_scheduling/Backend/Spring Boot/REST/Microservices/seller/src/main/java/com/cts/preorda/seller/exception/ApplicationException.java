package com.cts.preorda.seller.exception;

public class ApplicationException extends Exception{
	
	private String errorCode;
	private String errorMessage;
	
	public ApplicationException(Exceptions e){
		this.errorCode=e.errorCode;
		this.errorMessage=e.errorMessage;
		

	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	

}
