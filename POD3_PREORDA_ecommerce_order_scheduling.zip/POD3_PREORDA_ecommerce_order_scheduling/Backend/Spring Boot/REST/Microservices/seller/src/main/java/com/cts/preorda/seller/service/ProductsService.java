package com.cts.preorda.seller.service;

import java.util.List;
import java.io.UnsupportedEncodingException;
import java.util.*;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.preorda.seller.model.Products;
import com.cts.preorda.seller.repository.ProductsRepository;

@Service
public class ProductsService {

	@Autowired
	private ProductsRepository productsRepository;

	public List<Products> getAllProducts() {
		List<Products> products = productsRepository.findAll();
		for(Products product : products) {
			this.setEncodedImage(product);

		}
		return products;
	}

	/*
	 * public Products getProducts(int id) { return productsRepository.findById(id);
	 * }
	 */
	public Products saveProducts(Products product) {
		this.setImage(product);

		return productsRepository.save(product);
	}

	
	public void deleteProducts(int id) {
		productsRepository.deleteById(id);
	}


	public void update(Products product, int id) {
		// TODO Auto-generated method stub
		 //Products products = this.getProducts(id);
		this.setImage(product);
		productsRepository.save(product);  
		}

	public Products getProducts(int id) {
		// TODO Auto-generated method g
		Products products= productsRepository.findById(id).get();
		this.setEncodedImage(products);
		System.out.println(products.toString());
		return products;
	} 
	

private void setImage(Products products) {
	String partSeparator = ",";

	  String encodedImg = products.getImgSrc().split(partSeparator)[1];

	
     byte[] decodedString;
	try {
		decodedString = Base64.getDecoder().decode(new String(encodedImg).getBytes("UTF-8"));
		products.setImage(decodedString);
	} catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}

private void setEncodedImage(Products product) {
	if(Objects.nonNull(product.getImage())) {

        String base64String = Base64.getEncoder().encodeToString(product.getImage());
		product.setImgSrc("data:image/jpeg;base64,"+base64String);
		
	}
}

public List<Products> findByName(String name) {
	return productsRepository.findByName(name);
}
}



