package com.cts.preorda.seller.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.cts.preorda.seller.model.Seller;
import com.cts.preorda.seller.service.SellerService;


@RestController
@RequestMapping("/seller")
@CrossOrigin
public class SellerController {
	
	@Autowired
	SellerService sellerService;

	@PostMapping("/register")
	public String processRegister(@RequestBody Seller seller) {

		sellerService.storeSellerDetails(seller);
		
		return "register success";
	}
	@PutMapping("/edit-seller/{seller_Id}")  
	public Seller update(@RequestBody Seller seller,@PathVariable("seller_Id") int seller_Id)   
	{  
    this.sellerService.update(seller_Id,seller);  
    return seller;
	}  
	@GetMapping("/{seller_Id}")
	public Seller getSeller(@PathVariable int seller_Id) {
		return sellerService.getSeller(seller_Id);
	}

}
