package com.cts.preorda.seller.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class Inventory {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "inventory_id")
	private int inventory_id;
	
	@Override
	public String toString() {
		return "Inventory [inventory_id=" + inventory_id + ", seller_id=" + seller_id + ", product_id=" + product_id
				+ ", quantity=" + quantity + "]";
	}

	//@OneToOne(cascade = CascadeType.ALL)
	//@JoinColumn(name="inv_se_fk",referencedColumnName = "seller_id")
	private int seller_id;
	
	//@OneToMany(cascade = CascadeType.ALL, mappedBy = "inventory")
	private int product_id;
	private int quantity;

	public int getInventory_id() {
		return inventory_id;
	}

	public void setInventory_id(int inventory_id) {
		this.inventory_id = inventory_id;
	}

	public int getSeller_id() {
		return seller_id;
	}

	public void setSeller_id(int seller_id) {
		this.seller_id = seller_id;
	}

	public int getProduct_id() {
		return product_id;
	}

	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
	/*public void addElements(List<Products> p) {
		this.products = p;
			System.out.print(p);
		
	}*/


	/*public int findId() {
		return this.inventory_id;
	}*/
	
	
	
	//private int quantity;
//	private double price;
}
