package com.cts.preorda.seller.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.preorda.seller.exception.ApplicationException;
import com.cts.preorda.seller.model.Products;
import com.cts.preorda.seller.service.InventoryService;


@RestController
@RequestMapping("/inventory")
@CrossOrigin(origins = "http://localhost:3000/")
public class InventoryController {
	
	@Autowired
	public InventoryService inventoryService;
	
	@GetMapping("/products/user/{user_id}")
	public List<Products> getAllProducts(@PathVariable int user_id){
		return inventoryService.getAllProducts(user_id);
	}
	@GetMapping("/products/{id}")
	public Products getProducts(@PathVariable("id") int id) {
		
		Products product = inventoryService.getProducts(id);
		System.out.println(product);
		return product;
	}

	@GetMapping("/products/name/{name}")
	public List<Products> getByName(String name){
		return inventoryService.getByName(name);
	}
	
	@PostMapping("/products/save/{user_id}")
	public String saveProducts(@RequestBody Products product,@PathVariable int user_id) throws ApplicationException{
		//String name = product.findName(product);
		 inventoryService.saveProducts(product,user_id);
		return "Product saved successfully";
	}
	
	@DeleteMapping("/del-products/{id}")
	public void deleteProducts(@PathVariable("id") int id) {
		inventoryService.deleteProducts(id);
	}
	
	@PutMapping("/edit-products/{id}")
	public Products updateProducts(@RequestBody Products product,@PathVariable("id") int id) {
		
		inventoryService.update(product, id);
		return product;
	}
	
}
