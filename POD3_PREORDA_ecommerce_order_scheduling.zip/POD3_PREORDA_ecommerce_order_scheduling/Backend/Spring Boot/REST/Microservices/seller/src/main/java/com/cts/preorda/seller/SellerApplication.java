package com.cts.preorda.seller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import org.springframework.cloud.client.discovery.EnableDiscoveryClient;


@SpringBootApplication
@EnableDiscoveryClient
public class SellerApplication{

	public static void main(String[] args) {
		SpringApplication.run(SellerApplication.class, args);
	}

	/*@Autowired
	private ProductsRepository productsRepository;
	 implements CommandLineRunner
	@Override
	public void run(String... args) throws Exception {
		Products product = new Products();
		product.setBrand("Sunsilk");
		product.setDescription("Shampoo for silky hair");
		product.setPrice(500);
		product.setProduct_Name("shampoo");
		product.setQuantity(7);
		
	}*/
	
}
