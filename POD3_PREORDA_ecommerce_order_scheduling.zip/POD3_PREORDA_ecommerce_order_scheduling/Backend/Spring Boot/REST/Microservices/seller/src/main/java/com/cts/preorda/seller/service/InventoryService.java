package com.cts.preorda.seller.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.preorda.seller.exception.ApplicationException;
import com.cts.preorda.seller.exception.Exceptions;
import com.cts.preorda.seller.model.Inventory;
import com.cts.preorda.seller.model.Products;
import com.cts.preorda.seller.repository.InventoryRepository;
import com.cts.preorda.seller.repository.ProductsRepository;
import com.cts.preorda.seller.repository.SellerRepository;

@Service
public class InventoryService {

	@Autowired
	public ProductsService productService;

	@Autowired
	private ProductsRepository productsRepository;
	@Autowired
	public InventoryRepository inventoryRepo;
	@Autowired
	SellerRepository sellerRepo;


	public List<Products> getAllProducts(int user_id) {
		List<Inventory> inventory = inventoryRepo.findAll();
		//List<Products> products= productService.getAllProducts();
		List<Products> sellerProducts = new ArrayList<Products>();
//	int user_id=103;
		for(int i=0;i<inventory.size();i++)
			{
			//logined user's seller id
			
			if(inventory.get(i).getSeller_id()== user_id)
			{
			int product_id=inventory.get(i).getProduct_id();
			//System.out.println(productService.getProducts(product_id));
			sellerProducts.add(productService.getProducts(product_id));
			}
		}
		//System.out.println(sellerProducts);
		return sellerProducts;	

	}
	
	// decreasing the inventory quantity
	//String order_status = "placed";	
	//int inventory_id=2;
	//int quantity = 2;
	//int ordered_quantity =3;
//	public void decreaseinventory(int ordered_quantity,int product_id) throws ApplicationException
//	// pass order table object and get inventory id and quantity
//	{
//		List<Inventory> invn = inventoryRepo.findAll();
//		int inv_id = 0;
//		for(int i=0;i<invn.size();i++) {
//			if(invn.get(i).getProduct_id() == product_id) {
//				inv_id = invn.get(i).getInventory_id();
//			}
//		}
//		Inventory inv = inventoryRepo.findById(inventory_id);
//		int available =inv.getQuantity();	
//		if(available<ordered_quantity)
//		{
//			//exception has to be thrown
//			throw new ApplicationException(Exceptions.NO_AVAILABLE_PRODUCT);
//		}	
//		
//		int new_available= available-ordered_quantity;
//		inv.setQuantity(new_available);		
//		Products prod= productService.getProducts(product_id);
//		prod.setQuantity(new_available);
//	}
	
	
	  
	 
	

	public List<Products> getByName(String name) {
		return productService.findByName(name);
	}
	public Products getProducts(int id) {
		// TODO Auto-generated method g
		Products products= productService.getProducts(id);
		
		//System.out.println(products.toString());
		return products;
	} 
	
	
	
	
	
	
	public String saveProducts(Products product,int user_id) throws ApplicationException{
		// inv.addElements(productRepo.findById());
		/*
		 * if(!(isProductPresent(name))) { productRepo.save(product); int id =
		 * productRepo.findIdByName(name); inventoryRepo.save(inv); } else { }
		 */
		String name = product.getName();
		Inventory inv = new Inventory();
		List<Products> li = productService.findByName(name);
		if (li.size() >= 1) {
			int id = this.findProductId(name);
			//System.out.println("Product id is:" + id);
			// List<Products> p = productRepo.findAll();
			// inv.addElements(p);
//			inv.setProduct_id(id);
//			inv.setSeller_id(9876);
//			inventoryRepo.save(inv);

			throw new ApplicationException(Exceptions.NAME_EXIST);
		} else {
			
			productService.saveProducts(product);
			int id = this.findProductId(name);
			int quantity=product.getQuantity();
			// List<Products> p = new ArrayList<>();
			// p.add(product);
			// inv.addElements(p);
			// inventoryRepo.save(inv);
			//int user_id=103;
			inv.setProduct_id(id);
			inv.setSeller_id(user_id);
			inv.setQuantity(quantity);
			
			inventoryRepo.save(inv);
			// productRepo.fin
			
			return "Product added successfully";
		}
	}
	

	
	public int findProductId(String name) {

		List<Products> p = productService.findByName(name);
		Products pro1 = p.get(0);
		// System.out.println("Product list:"+pro1.getProduct_id());
		// int id = p.get(0).toString();
		return pro1.getId();
	}

	public void deleteProducts(int id){
		//Inventory inv = new Inventory();
		List<Inventory> inv = inventoryRepo.findAll();
		int inv_id = 0;
		for(int i=0;i<inv.size();i++) {
			if(inv.get(i).getProduct_id() == id) {
				inv_id = inv.get(i).getInventory_id();
			}
		}
		
		inventoryRepo.deleteById(inv_id);
		//productService.deleteProducts(id);
		productsRepository.deleteById(id);
	}
	
	
	
	

	public void update(Products product, int id) {
		productService.update(product,id);
		List<Inventory> inv = inventoryRepo.findAll();
		int inv_id = 0;
		for(int i=0;i<inv.size();i++) {
			if(inv.get(i).getProduct_id() == id) {
				inv_id = inv.get(i).getInventory_id();
			}
		}		
		//System.out.println(inv_id);
		Inventory invent = inventoryRepo.findById( inv_id);
		System.out.println(invent);
		//System.out.println(product.getQuantity());
		invent.setQuantity(product.getQuantity());
		inventoryRepo.save(invent);
		//System.out.println(invent.getQuantity());
		//System.out.println(invent);
		
	}

}
