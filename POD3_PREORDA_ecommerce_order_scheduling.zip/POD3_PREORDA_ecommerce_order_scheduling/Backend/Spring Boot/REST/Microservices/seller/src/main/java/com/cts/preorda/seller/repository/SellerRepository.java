package com.cts.preorda.seller.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

//import com.cts.preorda.customer.model.Customer;
import com.cts.preorda.seller.model.Seller;

@Repository
public interface SellerRepository extends JpaRepository<Seller,Integer> {
	@Query(value="select * from seller where user_id = :uid",nativeQuery = true)
	Seller getSeller(@Param("uid") int uid);
}
