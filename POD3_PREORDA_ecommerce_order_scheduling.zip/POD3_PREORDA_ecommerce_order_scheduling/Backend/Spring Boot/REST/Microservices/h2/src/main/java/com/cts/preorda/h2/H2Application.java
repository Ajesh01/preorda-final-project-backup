package com.cts.preorda.h2;

import java.sql.SQLException;

import org.h2.tools.Server;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class H2Application {

	public static void main(String[] args) throws SQLException {
		Server server = Server.createTcpServer("-tcp","-tcpAllowOthers","-ifNotExists","-pgAllowOthers").start();
		SpringApplication.run(H2Application.class, args);

	}

}
